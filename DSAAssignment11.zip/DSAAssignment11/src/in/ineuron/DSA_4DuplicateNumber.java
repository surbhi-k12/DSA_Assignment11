package in.ineuron;
import java.util.*;
public class DSA_4DuplicateNumber {

	    public static int findDuplicate(int[] nums) {
	        HashMap<Integer,Integer> map = new HashMap<>();
	        for(int i=0;i<nums.length;i++){
	            map.put(nums[i],map.getOrDefault(nums[i],0)+1);
	            if(map.get(nums[i])==2){
	                return nums[i];
	            }
	        }
	        return -1;
	    }
	    
	    public static void main(String[] args) {
			int[] nums= {1,3,4,2,2};
			int ans=0;
			ans=findDuplicate(nums);
			System.out.println(ans);
		}
	}


